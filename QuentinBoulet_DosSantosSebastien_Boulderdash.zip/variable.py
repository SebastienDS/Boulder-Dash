var = {
	"dimension_fenetre": 600,
	"nb_cases": 10,
	"debug": "d"
}

var["taille_case"] = var["dimension_fenetre"] // var["nb_cases"]


_touche = {
	"Right": (1, 0),
	"Left": (-1, 0),
	"Up": (0, -1),
	"Down": (0, 1)
}
